package com.bitlabs.ArogyaHospital;
import java.util.*;

/**
 * Hello world!
 *
 */
public class App {

    public static void main(String [] args) {
    DaoInterface dao=new DaoImpl();
    Patient p=new Patient();
    
    p.setId(1111);
    p.setAge(55);
    p.setName("murali");
    p.setGender("male");
    p.setCity("kerala");
    p.setAddress("mathippara,idukki");
    p.setGuardian_name("saji");
    p.setGuardian_address("kochera,idukki");
    p.setDateOfAdmission("2015/10/25");
    p.setAadhar_Card_number(455498);
    p.setContact_number(85725);
    p.setGuardian_contactNumber(454325);
   
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter any of 1 to perform mentioned activity :");
    System.out.println(" 1: for patientRegistration \n 2: for viewAllPatient  \n 3: for SearchPatientByid \n"
    		+ " 4: for DeletePatient By id \n 5: for SearchPatientByCity ");
   
    int n=sc.nextInt();
    switch(n)
    {
    case 1:if(n==1)
    	        dao.patientRegistration(p);
                break;
    case 2:if(n==2)
    			dao.viewAllPatient();
    			break;
    case 3:if(n==3)
    			dao.searchPatientById(102);
    			break;
    case 4:if(n==4)
    	 		dao.deletePatientById(103);
    			break;
    case 5:if(n==4)
    			dao.searchPatientByCity("guntur");
    			break;
    case 6:if(n==4)
    			dao.searchPatientByAgeGroup(18, 55);
    			break;
      
    }
       
}

}
